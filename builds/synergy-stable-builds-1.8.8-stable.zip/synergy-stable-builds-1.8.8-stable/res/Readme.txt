Thank you for chosing Synergy!
http://symless.com/

Synergy allows you to share your keyboard and mouse between computers over a network.

For FAQ, setup, and usage instructions, please visit our online Readme:
http://symless.com/pm/projects/synergy/wiki/Readme

Have fun!

Thanks,
The Synergy Team
