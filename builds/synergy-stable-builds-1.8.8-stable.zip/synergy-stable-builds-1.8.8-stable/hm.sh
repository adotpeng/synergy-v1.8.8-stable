#! /bin/bash

python hm.py "$@"
